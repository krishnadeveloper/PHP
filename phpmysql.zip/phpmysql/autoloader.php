<?php 
/**
*	Author : Krishna Kumar
*	Date : 20-Dec-2018
*/

require_once "config/config.php"; // Load configuration

// Database connection
$db = new mysqli(DBHOST,DBUSER,DBPASS,DBNAME);
$connectionStatusMessage = "No.";
$connectionStatus = false;
if(is_array(mysqli_get_connection_stats($db))){
	$connectionStatusMessage = "Yes.";
	$connectionStatus = true;
}


spl_autoload_register(function($className) {
	include_once 'classes/' . $className . '.php';
	
});



// Start session 
if (version_compare(PHP_VERSION, '5.4.0', '<')) 
{
    if(session_id() == '') {session_start();}
} 
else  
{
   if (session_status() == PHP_SESSION_NONE) 
   		{
   			session_start();
   		}
}


?>
