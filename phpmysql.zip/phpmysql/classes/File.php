<?php 
/**
*	Author : Krishna Kumar
*	Date : 20-Dec-2018
*/


class File
{
	
	public static function put($path,$content)
	{
		return move_uploaded_file($content, $path);
	}

	
}

?>