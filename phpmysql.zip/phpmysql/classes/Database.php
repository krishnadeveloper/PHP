<?php
/**
* 
*/
class Database 
{	

	public static $DB;

	public function __construct($db)
	{
		self::$DB = $db;
	}

	public static function insertQuery($table,$params)
	{
		$columns = array_keys($params);
		$values  = array_values($params);

		$columns = '`'.join('`,`',$columns).'`';
		$values = "'".join("','",$values)."'";
		
		$query = "insert into ".$table." (".$columns.") values (".$values.")";

		return self::$DB->query($query);

	}

	public static function updateUser($table,$values,$id)
	{
		
		$columns = "";

		foreach ($values as $key => $value) {
			$columns .= "`".$key."` = '".$value."', ";
		}
		$columns  = substr($columns, 0,-2);
		$query = "update ".$table." set ".$columns." where id=".$id;
		return self::$DB->query($query); 

	}


	public static function rawQuery($query)
	{	

		return self::$DB->query($query);	
	}

	public static function findById($table,$id)
	{
		$query = 'select * from '.$table.' where id='.$id;
		$result = self::$DB->query($query); 
		return $result->fetch_array(MYSQLI_ASSOC);
	}

	

}
?>
