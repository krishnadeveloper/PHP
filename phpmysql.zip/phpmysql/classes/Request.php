<?php 
/**
*	Author : Krishna Kumar
*	Date : 20-Dec-2018
*/


class Request
{
	public static $File;
	public static $fileTypes = array('jpg','png');

	public static function input($inputName)
	{
		return $_REQUEST[$inputName];
	}

	public static function all()
	{
		return $_REQUEST;
	}

	public static function isMethod($method)
	{

		return strtoupper($_SERVER['REQUEST_METHOD'])==strtoupper($method)?true:false;

	}

	public static function method()
	{
		return $_SERVER['REQUEST_METHOD'];
	}


	public static function hasFile($fileName){
		self::$File = $_FILES[$fileName]; 
		return $_FILES[$fileName]['name']!=''?true:false;
	}

	public static function fileDetails()
	{
		return self::$File;
	}

	public static function fileName()
	{
		return self::$File['name'];
	}

	public static function setAllowedFileTypes($types = array())
	{
		array_merge(self::$fileTypes,$types);
	}


	public static function allowedFileTypes()
	{
		return in_array($extention, self::$fileType);
	}

	public static function isExtention($extention)
	{
		return in_array($extention, self::$fileTypes);	
	}

	public static function newFilenameWithExtention()
	{
		return time().rand().'.'.self::fileType();
	}

	public static function fileType()
	{
		return strtolower(pathinfo(self::$File['name'],PATHINFO_EXTENSION));
	}


}

?>
