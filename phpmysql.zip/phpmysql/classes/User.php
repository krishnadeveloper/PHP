<?php 
/**
*	Author : Krishna Kumar
*	Date : 20-Dec-2018
*/


class User
{
	public static $userDetails;


	public static function setUserData($userdata)
	{
		
		self::$userDetails = $userdata;
	}

	public static function Id()
	{
		return self::$userDetails['id'];
	}


	public static function fullname()
	{
		//print_r(self::$userDetails);
		return self::$userDetails['first_name'].' '.self::$userDetails['last_name'];
	}

	public static function firstName()
	{
		return self::$userDetails['first_name'];
	}

	public static function lastName()
	{
		return self::$userDetails['last_name'];
	}


	public static function email()
	{
		return self::$userDetails['email'];
	}

	public static function image()
	{
		return self::$userDetails['image']!=''?'upload/'.self::$userDetails['image']:'';
	}

	
}
?>