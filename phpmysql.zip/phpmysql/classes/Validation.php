<?php 
/**
*	Author : Krishna Kumar
*	Date : 20-Dec-2018
*/


class Validation
{
	public static $validation = false;
	public static $errors	= array();
	public static function make($inputFields = array(), $inputRules = array(), $customMessages = null)
	{
		
		if(count($inputFields)>0)
		{

			foreach ($inputRules as $inputName => $allRules) 
			{

				$allRules = explode('|', $allRules);

				if(self::isArray($allRules))
					{
						foreach ($allRules as $rule) 
						{	


							if(!self::checkValid($inputFields[$inputName],$rule,$inputFields))
								{
									self::$errors[$inputName][] = self::message($inputName,$rule);
									
								}
								

						}
					}

			}

		}
	}

	public static function checkValid($inputValue, $rule,$inputValues=array())
	{
		self::$validation = false; // Default, when validation pass then it will return true else false (default)
		$inputvalue2 = "";
		if(strrpos($rule, ':')>-1){
			$rules = explode(':', $rule);
			$rule = $rules['0'];
			$inputvalue2 = isset($inputValues[$rules[1]])?$inputValues[$rules[1]]:'';
		}

		switch ((string)$rule) {
			case "required":
				self::$validation = self::isRequired($inputValue);
				break;
			case "email":
				self::$validation = self::isEmail($inputValue);
				break;
			case "int":
				self::$validation = self::isInt($inputValue);
				break;
			case "equal":
				self::$validation = self::match($inputValue,$inputvalue2);
				break;
			default:
				self::$validation = true;
				break;
		}

		return self::$validation;
	}


	public static function message($inputName,$rule)
	{
		$message = ''; // Default, when validation pass then it will return true else false (default)
		$field2 = "";
		if(strrpos($rule, ':')>-1){
			$rules = explode(':', $rule);
			$rule = $rules['0'];
			$field2 = $rules['1'];
		}
		switch ($rule) {

			case "required":
				$message = 'The '.$inputName.' is required.';
				break;
			case "email":
				$message = 'The '.$inputName.' is not valid email.';
				break;
			case "int":
				$message = 'The '.$inputName.' is not integer.';
				break;
			case "equal":
				$message = 'The '.$inputName.' does not match with '.$field2;
				break;

			default:
				$message = '';
				break;
		}

		return $message;
	}

	public static function isArray($inputValue)
	{
		return is_array($inputValue);
	}

	public static function isInt($inputValues)
	{
		return is_integer($inputValues);
	}

	public static function match($inputValue,$inputValue2)
	{

		return (self::isTrim($inputValue)==self::isTrim($inputValue2) && (self::isTrim($inputValue)!='' && self::isTrim($inputValue2) !=''))?true:false;
	}

	public static function isRequired($inputValue)
	{
		return (self::isTrim($inputValue)=='' || self::isTrim($inputValue)==null || $inputValue==='')?false:true; 
	}

	public static function isEmail($inputValue)
	{
		return filter_var(trim($inputValue), FILTER_VALIDATE_EMAIL);
	}

	public static function isTrim($inputValue)
	{
		return trim($inputValue);
	}

	public static function fails()
	{
		return !self::$validation;
	}

	public function passes()
	{
		return self::$validation;
	}

	public static function errorMessages()
	{
		return self::$errors;
	}

}

?>
