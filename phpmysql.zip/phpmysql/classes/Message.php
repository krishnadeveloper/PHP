<?php
/**
* 
*/
class Message
{
	
	public static function Connection()
	{
		$message = \Session::getFlush('connection');
		if(is_array($message))
		{

			echo join('<br>',$message);

		}
		else
		{

			echo $message;
		}
		 
	}

}
?>