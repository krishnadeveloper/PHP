<?php 
/**
* 
*/
class Url
{
	
	// Redirection
	public static function redirect($url)
	{
		
		header("Location:".$url);
		exit;
	}

}

?>