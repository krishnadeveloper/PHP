<?php 
/**
* 
*/

class Auth 
{

	
	public static function guest()
	{
		return !\Session::has('user');
	}

	public static function isLogin()
	{
		return \Session::has('user');
	}	

	public static function attempt($email,$password){

		$result    =    $db->query('select * from users where email="'.$email.'" and password="'.md5($password).'"');
		$loginStatus = false;
		$userData = $result->fetch_array(MYSQLI_ASSOC);
		if (count($userData)) 
		{

			\Session::set('user',$userData);
			$loginStatus = true;

		}

		return $loginStatus;

	}


}

?>