<?php 
/**
*	Author : Krishna Kumar
*	Date : 20-Dec-2018
*/

class Session
{


	public static function has($sessionKey)
	{
		return isset($_SESSION[$sessionKey])?true:false;
	}

	public static function set($sessionKey,$sessionValue)
	{

		$_SESSION[$sessionKey] = $sessionValue;
	}

	public static function get($sessionKey)
	{
		if(isset($_SESSION[$sessionKey])){
			return $_SESSION[$sessionKey];
		}
	}

	public static function remove($sessionKey)
	{
		if(isset($_SESSION[$sessionKey]))
		{
			unset($_SESSION[$sessionKey]);
		}
		
	}

	public static function setFlush($sessionKey,$sessionValue)
	{
		$_SESSION[$sessionKey] = $sessionValue;
	}

	public static function getFlush($sessionKey)
	{
		if(isset($_SESSION[$sessionKey])){
			$flushMessage = $_SESSION[$sessionKey];
			unset($_SESSION[$sessionKey]);
			return $flushMessage;
		}
	}

	public static function all()
	{

		return $_SESSION;
	}

	public static function destroy()
	{
		session_destroy();
	}

	
}

?>