<?php 
//error_reporting(1); // Error resporting off
define('DBHOST', 'localhost'); // Database Host
define('DBUSER', 'root'); // Database username
define('DBPASS', ''); // Database password
define('DBNAME', 'phpmysql'); // Database name

?>