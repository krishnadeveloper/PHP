<?php
require 'autoloader.php';

Session::remove('user');
Session::destroy();

Url::redirect("login.php");

?>