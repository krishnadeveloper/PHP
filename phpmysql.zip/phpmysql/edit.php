<?php 
require 'autoloader.php';

$errors = array(); // Error variable

$DB = new Database($db);
$userDetails = $DB->findById('users',Session::get('user')['id']);
User::setUserData($userDetails);

if(Request::isMethod('post'))
{

    // Login Input Validation

    Validation::make(
        Request::all(),
        [
            'email'    =>    "required|email",
            'firstname'    =>    "required",
            'lastname'    =>    "required",
        ]
    );

    // When validation fails
    if(Validation::fails())
        {
            $errors   =    Validation::errorMessages(); // Validation errors
        }
        else
        {
            $uploadedFilename = "";
            if(Request::hasFile('image'))
                {
                    Request::setAllowedFileTypes(['jpeg','jpg','png']);
                    if(Request::isExtention(Request::fileType()))
                        {
                            
                            $imageFile = Request::fileDetails();
                            $uploadedFilename = Request::newFilenameWithExtention();

                            if(!File::put('upload/'.$uploadedFilename,$imageFile['tmp_name']))
                            {
                                $insertRecord = false;
                                array_push($errors, array('file','File upload is failed'));   
                            }

                        }
                        else
                        {
                            
                            array_push($errors, 'Please upload a valid file, Only jpeg, jpg and png files are allowed');   
                        }
                }
                
                
            if(count($errors) <= 0)
            {
                $result = false;

                if($uploadedFilename!='')
                {
                    $result   =    $DB->updateUser('users',[
                                    'email' => Request::input('email'),
                                    'first_name' => Request::input('firstname'),
                                    'last_name' => Request::input('lastname'),
                                    'image' => $uploadedFilename
                                ],
                                User::Id()
                            );
                }
                else
                {
                    $result   =    $DB->updateUser('users',[
                                    'email' => Request::input('email'),
                                    'first_name' => Request::input('firstname'),
                                    'last_name' => Request::input('lastname')
                                ],
                                User::Id()
                            );
                }
            
                if ($result) 
                {
                    Session::setFlush('success','Profile updated successfully.');
                    Url::redirect("profile.php");

                }else{
                    Session::setFlush('error','Registration failed.');
                    
                }

            }
        }
}


// Validate Authorised user
if(!Auth::isLogin()){
    Url::redirect("login.php");
}


if(!$connectionStatus)
{
    Session::setFlush('connection','Database connection is missing');
    Url::redirect("index.php");   
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript">
</script>
</head>
<body>


    <div class="container">    
        
        <div id="signupbox" style="margin-top:50px" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="panel-title">Edit Profile</div>
                            <div style="float:right; font-size: 85%; position: relative; top:-10px"><a id="signinlink" href="profile.php">View Profile</a></div>
                        </div>  
                        <div class="panel-body" >
                            <form  class="form-horizontal" action="" role="form" method="post" enctype="multipart/form-data" >
                                
                                
                                    <?php

                                    // Show validation errors
                                    if (count($errors)) {
                                        echo '<div id="signupalert" style="display:block;" class="alert alert-danger">';
                                        foreach ($errors as $key => $value) {
                                            
                                            if(is_array($value))
                                            {
                                                echo '<span><br>'.implode('</span><br><span>', $value).'</span>';
                                            }
                                            else 
                                            {
                                                echo '<span><br>'.$value.'</span>';
                                            }
                                            
                                            
                                        }

                                        echo '</div>';
                                    }

                                    
                                    ?>
                                

                                <?php 

                                if(Session::get('error')){
                                        echo '<div style="display:block;" id="login-alert" class="alert alert-danger col-sm-12">'.Session::getFlush('error').'</div>';
                                    }

                                ?>
                                    
                                
                                  
                                <div class="form-group">
                                    <label for="email" class="col-md-3 control-label">Email</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="email" placeholder="Email Address" value="<?php echo User::email(); ?>">
                                    </div>
                                </div>
                                    
                                <div class="form-group">
                                    <label for="firstname" class="col-md-3 control-label">First Name</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="firstname" placeholder="First Name" value="<?php echo User::firstName(); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="lastname" class="col-md-3 control-label">Last Name</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="lastname" placeholder="Last Name" value="<?php echo User::lastName(); ?>">
                                    </div>
                                </div>    
                                <div class="form-group">
                                    <label for="icode" class="col-md-3 control-label">User Image</label>
                                    <div class="col-md-9">
                                        <input type="file" class="form-control" name="image" placeholder="">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <!-- Button -->                                        
                                    <div class="col-md-offset-3 col-md-9">
                                        <button id="btn-signup" type="submit" class="btn btn-info"><i class="icon-hand-right"></i> &nbsp Sign Up</button>
                                        
                                    </div>
                                </div>
                                
                                
                                
                                
                                
                            </form>
                         </div>
                    </div>

               
               
                
         </div> 
    </div>
    
</body>
</html>