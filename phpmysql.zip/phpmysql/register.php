<?php 
require 'autoloader.php';

$errors = array(); // Error variable

$DB = new Database($db);


if(Request::isMethod('post'))
{

    // Login Input Validation

    Validation::make(
        Request::all(),
        [
            'email'    =>    "required|email",
            'firstname'    =>    "required",
            'lastname'    =>    "required",
            'password'    =>    "required",
            'confirmpassword'    =>    "required|equal:password",
        ]
    );

    // When validation fails
    if(Validation::fails())
        {
            $errors   =    Validation::errorMessages(); // Validation errors
        }
        else
        {
            $uploadedFilename = "";
            $insertRecord = true;
            if(Request::hasFile('image'))
                {
                    Request::setAllowedFileTypes(['jpeg','jpg','png']);
                    if(Request::isExtention(Request::fileType()))
                        {
                            $insertRecord = true;
                            $imageFile = Request::fileDetails();
                            $uploadedFilename = Request::newFilenameWithExtention();

                            if(!File::put('upload/'.$uploadedFilename,$imageFile['tmp_name']))
                            {
                                $insertRecord = false;
                                array_push($errors, array('file','File upload is failed'));   
                            }
                            else
                            {
                                $insertRecord = true;
                            } 
                        }
                        else
                        {
                            $insertRecord = false;
                            array_push($errors, 'Please upload a valid file, Only jpeg, jpg and png files are allowed');   
                        }
                }
                else{

                    $insertRecord = false;
                    array_push($errors, 'Please select a file.');
                }
                
            if($insertRecord)
            {
                $result   =    $DB->insertQuery('users',[
                                    'email' => Request::input('email'),
                                    'first_name' => Request::input('firstname'),
                                    'last_name' => Request::input('lastname'),
                                    'password' => md5(Request::input('password')),
                                    'image' => $uploadedFilename
                                ]);

                //$DB->rawQuery('insert into users (`email`,`first_name`,`last_name`,`password`,`image`) values("'.Request::input('email').'","'.Request::input('firstname').'","'.Request::input('lastname').'","'.md5(Request::input('password')).'","'.$uploadedFilename.'")');

            
                if ($result) 
                {
                    Session::setFlush('success','You have registered successfully.');
                    Url::redirect("login.php");

                }else{
                    Session::setFlush('registration','Registration failed.');
                    
                }

            }
        }
}


// Validate Authorised user
if(!Auth::guest()){
    Url::redirect("profile.php");
}


if(!$connectionStatus)
{
    Session::setFlush('connection','Database connection is missing');
    Url::redirect("index.php");   
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript">
</script>
</head>
<body>


    <div class="container">    
        
        <div id="signupbox" style="margin-top:50px" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="panel-title">Sign Up</div>
                            <div style="float:right; font-size: 85%; position: relative; top:-10px"><a id="signinlink" href="login.php">Sign In</a></div>
                        </div>  
                        <div class="panel-body" >
                            <form id="signupform" class="form-horizontal" action="" role="form" method="post" enctype="multipart/form-data" >
                                
                                
                                    <?php

                                    // Show validation errors
                                    if (count($errors)) {
                                        echo '<div id="signupalert" style="display:block;" class="alert alert-danger">';
                                        foreach ($errors as $key => $value) {
                                            
                                            if(is_array($value))
                                            {
                                                echo '<span><br>'.implode('</span><br><span>', $value).'</span>';
                                            }
                                            else 
                                            {
                                                echo '<span><br>'.$value.'</span>';
                                            }
                                            
                                            
                                        }

                                        echo '</div>';
                                    }

                                    
                                    ?>
                                

                                <?php 

                                if(Session::get('registration')){
                                        echo '<div style="display:block;" id="login-alert" class="alert alert-danger col-sm-12">'.Session::getFlush('registration').'</div>';
                                    }

                                ?>
                                    
                                
                                  
                                <div class="form-group">
                                    <label for="email" class="col-md-3 control-label">Email</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="email" placeholder="Email Address">
                                    </div>
                                </div>
                                    
                                <div class="form-group">
                                    <label for="firstname" class="col-md-3 control-label">First Name</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="firstname" placeholder="First Name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="lastname" class="col-md-3 control-label">Last Name</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="lastname" placeholder="Last Name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="password" class="col-md-3 control-label">Password</label>
                                    <div class="col-md-9">
                                        <input type="password" class="form-control" name="password" placeholder="Password">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="password" class="col-md-3 control-label">Conform Password</label>
                                    <div class="col-md-9">
                                        <input type="password" class="form-control" name="confirmpassword" placeholder="Confirm Password">
                                    </div>
                                </div>
                                    
                                <div class="form-group">
                                    <label for="icode" class="col-md-3 control-label">User Image</label>
                                    <div class="col-md-9">
                                        <input type="file" class="form-control" name="image" placeholder="">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <!-- Button -->                                        
                                    <div class="col-md-offset-3 col-md-9">
                                        <button id="btn-signup" type="submit" class="btn btn-info"><i class="icon-hand-right"></i> &nbsp Sign Up</button>
                                        
                                    </div>
                                </div>
                                
                                
                                
                                
                                
                            </form>
                         </div>
                    </div>

               
               
                
         </div> 
    </div>
    
</body>
</html>