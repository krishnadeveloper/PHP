<?php
require 'autoloader.php';
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Mini Project Home - PHP</title>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!-- Home page css -->
<link rel="stylesheet" type="text/css" href="assets/css/home/home.css">

</head>
<body>


    <div class="container">    
        <div class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
            <div class="panel panel-info" >

                    <div class="panel-heading">
                        <div class="panel-title text-center">Hey <?php echo Auth::guest()?'Guest User!':'Logged In User!' ?>,  Welcome to Mini Project</div>
                    </div>     

                    <div style="padding-top:30px" class="panel-body" >
                        <?php 
                            echo Message::Connection();
                        ?>
                        <h4 class="text-center">Information</h4>
                        <p>
                            Author : Krishna Kumar<br>
                            Date : 20-Dec-2018<br>
                            Email : getkrishnakumar1990@gmail.com
                        </p>

                        <h4 class="text-center">Content</h4>
                        
                        <ol>
                            <li>Home page</li>
                            <li>User login/signup</li>
                            <li>User profile</li>
                            <li>Update profile</li>
                        </ol>
                        <h4 class="text-center">Database</h4>
                        
                        <p class="<?php echo $connectionStatus? 'text-success':'text-warning' ?>">
                            Connected : <?php echo $connectionStatusMessage ?><br>
                        </p>

                        <div class="col-sm-6 col-md-12">
                            <a href="login.php" class="btn btn-success">Login <span class="glyphicon glyphicon-log-in"></span></a>

                        </div>
                        
                    </div>                     
            </div>  
        </div> 
        </div>    
    </div> 
    
</body>
</html>